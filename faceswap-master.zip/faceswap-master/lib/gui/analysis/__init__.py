#!/usr/bin/env python3
""" Methods for querying and compiling statistical data for the Faceswap GUI Analysis tab. """

from .stats import Calculations, _SESSION as Session  # noqa

************
utils module
************

.. automodule:: lib.utils
   :members:
   :undoc-members:
   :show-inheritance:

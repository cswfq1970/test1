*************
logger module
*************

.. automodule:: lib.logger
   :members:
   :undoc-members:
   :show-inheritance:

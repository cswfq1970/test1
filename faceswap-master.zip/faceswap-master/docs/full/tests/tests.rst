*************
tests package
*************

The Tests Package provides Faceswap's Unit Tests.

.. contents:: Contents
   :local:

Subpackages
===========

.. toctree::
   :maxdepth: 1

   lib
   tools

#!/usr/bin/env python3
""" Base class for Aligner plugins ALL aligners should at least inherit from this class. """

from .aligner import Aligner, AlignerBatch, BatchType
